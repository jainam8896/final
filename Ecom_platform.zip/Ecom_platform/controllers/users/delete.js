const User = require("../../models/User");
const CustomError = require("../../utils/errors/CustomError");

const deleteUser = async (req, res, next) => {
  try {
    const { id } = req.params;
    const user = await User.findByIdAndDelete(id);
    if (!user) {
      return next(new CustomError("User Not Found", 404));
    }
    return res
      .status(200)
      .send({ status: "success", message: "User Deleted Successfully" });
  } catch (error) {
    res.json(error.message);
  }
};

module.exports = deleteUser;
