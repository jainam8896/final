const Review = require("../../models/Reviews");

const addReview = async (req, res) => {
  const { productId } = req.params;
  const { reviews } = req.body;
  const review = new Review({
    reviews: reviews,
    userId: req.user._id,
    productId: productId,
  });
  const newReview = await review.save();
  return res.status(201).send(newReview);
};

module.exports = addReview;
