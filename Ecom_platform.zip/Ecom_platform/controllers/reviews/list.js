const Review = require("../../models/Reviews");
const CustomError = require("../../utils/errors/CustomError");

const listReview = async (req, res) => {
  const review = await Review.find({});
  if (!review){
    return next(new CustomError("No Review found", 404));
  } 
  return res.status(201).send(review);
};

module.exports = listReview
