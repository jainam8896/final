const User = require("../../models/User");
const bcrypt = require("bcrypt");
const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
const CustomError = require("../../utils/errors/CustomError");

//User login
const userLogin = async (req, res, next) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email: email });
    if (!user) {
      return next(new CustomError("User Not Register", 404));
    }
    const match = bcrypt.compareSync(password, user.password);
    if (!match) {
      return next(new CustomError("Email Or Password doesn't match", 401));
    }
    const token = jwt.sign({ _id: user._id }, process.env.JWT_SECRET_KEY, {
      expiresIn: "20m",
    });
    console.log(token);
    return res
      .status(200)
      .json({ status: "success", message: "User Login Success", token: token });
  } catch (error) {
    console.log(error);
    return next(new CustomError("Unable to Login", 500))
  }
};

module.exports = userLogin;
