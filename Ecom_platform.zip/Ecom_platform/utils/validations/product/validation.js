const { body } = require("express-validator");

const productValidator = [
  body("name").notEmpty().withMessage("Product is required"),
  body("description").notEmpty().withMessage("Product Description is required"),
  body("price").isInt().withMessage("Product Price Is Required"),
  body("qty").isInt().withMessage("Product Price Is Required"),
  body("image")
    .custom((value, { req }) => {
      if (
        req.file.mimetype === "image/jpg" ||
        req.file.mimetype === "image/jpeg" ||
        req.file.mimetype === "image/png"
      ) {
        return true;
      } else {
        return false;
      }
    })
    .withMessage("Please upload jpg, png, or jpeg file"),
  body("categoryId").notEmpty().withMessage("Category is required"),
];

module.exports = {productValidator}