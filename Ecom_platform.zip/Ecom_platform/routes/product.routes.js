const express = require("express");
const router = express.Router();
const rules = require("../utils/validations/product/validation.js");
const validate = require("../middlewares/validate.js");
const createProduct = require("../controllers/products/create");
const deletProduct = require("../controllers/products/delete.js");
const getProduct = require("../controllers/products/get.js");
const listProduct = require("../controllers/products/list.js");
const updateProduct = require("../controllers/products/update.js");
const upload = require("../helper/productimageupload.js");

//Create Product
router.post(
  "/create",
  upload.single("image"),
  validate(rules.productValidator),
  createProduct
);

//Delete Category
router.delete("/:id", deletProduct);

//Get Product
router.get("/:id", getProduct);

//Display Product
router.post("/", listProduct);

//Update Product
router.put("/:id", updateProduct);

module.exports = router;
