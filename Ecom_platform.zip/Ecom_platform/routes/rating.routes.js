const express = require("express");
const router = express.Router();
const addRating = require("../controllers/rating/add");
const deleteRating = require("../controllers/rating/delete");
const listRating = require("../controllers/rating/list");
const updateRating = require("../controllers/rating/update");

//Add  Rating
router.post("/:productId", addRating)

//Delete Rating
router.delete("/:id",deleteRating)

//List Rating
router.get("/",listRating)

//Update Rating
router.patch("/:productId/ratings/:id", updateRating)


module.exports = router;