const express = require("express");
const router = express.Router();
const addItemToCart = require("../controllers/cart/add");
const getCart = require("../controllers/cart/get");
const removeCart = require("../controllers/cart/delete");
const decreaseQty = require("../controllers/cart/decrease");

//Add Item
router.post("/:productId", addItemToCart);

//Decerease The Qty
router.patch("/:productId", decreaseQty);

//Display The Cart
router.get("/", getCart);

//Delete The Cart
router.delete("/:productId", removeCart);


module.exports = router;
